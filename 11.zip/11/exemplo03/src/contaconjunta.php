<?php

class ContaConjunta extends ContaEspecial
{

}