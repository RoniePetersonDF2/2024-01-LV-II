<?php

namespace App\Exceptions;
class TestException extends \Exception
{
    
}