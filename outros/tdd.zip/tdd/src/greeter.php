<?php

namespace App;

use App\Exceptions\TestException;

class Greeter
{
    public function greet(string $name): string
    {
        return "Hello, $name!";
    }

    public function dispararException(): void
    {
        throw new TestException();
    }
}