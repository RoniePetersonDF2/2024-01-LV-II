<?php
use PHPUnit\Framework\TestCase;

use App\Greeter;
use App\Exceptions\TestException;
final class ExceptionTest extends TestCase
{
    public function testException(): void
    {
        $this->expectException(TestException::class);
        $greeter = new Greeter;

        $greeter->dispararException();
    }
}